Project one was implemented on Xampp platform and webstorm.
d3, html and svg were used in the implementation
Webstorm interface was chosen in this implementation due to its easy 
connectivity with  d3.js.
Xampp provided a cloud interface to make it easy to run d3.js.

Email:
dmose@iu.edu.
Dennis Masigwa.
 