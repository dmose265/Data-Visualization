# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 18:20:45 2021

@author: Dennis Masigwa
"""
# Import vtk package to access VTK classes/functions. 
import vtk

from vtk.util.misc import vtkGetDataRoot
VTK_DATA_ROOT = vtkGetDataRoot()
import os
try:
    vtk.VTK_DATA = os.environ['VTK_DATA']
except KeyError:
    vtk.VTK_DATA = '..../.../vtkdata/'

# 1.CT Half Head
#*****************************************************************************

print ("interactive VTK program to explore the iso-surfaces of half headsq volume dataset")   

filename = "headsq/half"
reader = vtk.vtkVolume16Reader()
reader.SetDataDimensions(128,128)
reader.SetImageRange(1,93)
reader.SetFilePrefix(filename)
print("Reading volume dataset from " + filename + " ...")

reader.Update()  # executing reader
print("Dataset successfully loaded")   
x, y, z = reader.GetOutput().GetDimensions()
print("The dimensions are: %i %i %i" % (x, y, z))
min = 0 #minimum slider value
max = 256 #Maximum slider value
print("Use your mouse to interact with the Isosurface_Interactive_Slider & object")
# isoSurface
iso = vtk.vtkContourFilter() 
iso.SetInput(reader.GetOutput()) 
iso.SetValue( 0, (min + max) / 2 )

# Cleaning duplicate points
clean = vtk.vtkCleanPolyData()
clean.SetInput( iso.GetOutput() ) 

#normalizing
normals = vtk.vtkPolyDataNormals()
normals.SetInput( iso.GetOutput() )
normals.SetFeatureAngle(45)

isoMapper = vtk.vtkPolyDataMapper() 
isoMapper.SetInput( normals.GetOutput() ) 
isoMapper.SetColorModeToMapScalars()    

isoActor = vtk.vtkActor() 
isoActor.SetMapper( isoMapper )
  
#Create the outline  
outline = vtk.vtkOutlineFilter() 
outline.SetInput( reader.GetOutput() ) 
outlineMapper = vtk.vtkPolyDataMapper() 
outlineMapper.SetInput( outline.GetOutput() )
outlineActor = vtk.vtkActor() 
outlineActor.SetMapper( outlineMapper ) 
outlineActor.GetProperty().SetColor(0.0,0.0,0.0)

# renderer and render window 
rend = vtk.vtkRenderer() 
rend.SetBackground(0.95, 0.44, 0.48)
rendWin = vtk.vtkRenderWindow() 
rendWin.SetSize( 600, 600 ) 
rendWin.AddRenderer( rend ) 


# render window interactor 
int_rend = vtk.vtkRenderWindowInteractor() 
int_rend.SetSize(1600,1600)
int_rend.SetRenderWindow( rendWin ) 
 
# add the actors 
rend.AddActor( outlineActor ) 
rend.AddActor( isoActor )    


#  Interactive Slider representation
#******************************************************************************

def vtkSliderCallback2(obj, event):
    sliderRep = obj.GetRepresentation()
    position = sliderRep.GetValue()
    print "Position ",position
    iso.SetValue(0, position)
  
SliderRep = vtk.vtkSliderRepresentation2D()
SliderRep.SetMinimumValue(min)
SliderRep.SetMaximumValue(max)
SliderRep.SetValue((min + max) / 2)

SliderRep.SetTitleText("Isosurface_Interactive_Slider")
SliderRep.GetPoint1Coordinate().SetCoordinateSystemToNormalizedDisplay()
SliderRep.GetPoint1Coordinate().SetValue(0.3, 0.05)
SliderRep.GetPoint2Coordinate().SetCoordinateSystemToNormalizedDisplay()
SliderRep.GetPoint2Coordinate().SetValue(0.7, 0.05)

SliderRep.SetSliderLength(0.02)
SliderRep.SetSliderWidth(0.03)
SliderRep.SetEndCapLength(0.01)
SliderRep.SetEndCapWidth(0.03)
SliderRep.SetTubeWidth(0.005)
SliderRep.SetLabelFormat("%3.0lf")
SliderRep.SetTitleHeight(0.02)
SliderRep.SetLabelHeight(0.02)
SliderRep.GetSelectedProperty().SetColor(0,1,0)

SliderWidget = vtk.vtkSliderWidget()
SliderWidget.SetInteractor(int_rend)
SliderWidget.SetRepresentation(SliderRep)
SliderWidget.KeyPressActivationOff()
SliderWidget.SetAnimationModeToAnimate()
SliderWidget.SetEnabled(True)
SliderWidget.AddObserver("EndInteractionEvent", vtkSliderCallback2)

# Pipeline execution
rendWin.Render() 

# Interactor initializer and start
int_rend.Initialize() 
int_rend.Start() 




