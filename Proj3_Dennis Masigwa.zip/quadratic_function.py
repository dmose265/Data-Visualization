# -*- coding: utf-8 -*-
"""
Created on Fri Apr 30 18:20:45 2021
Dennis Masigwa
"""

# Importing vtk  
import vtk
from vtk.util.misc import vtkGetDataRoot
VTK_DATA_ROOT = vtkGetDataRoot()
import os
try:
    vtk.VTK_DATA = os.environ['VTK_DATA']
except KeyError:
    vtk.VTK_DATA = '..../.../vtkdata/'

def vtkSliderCallback2(obj, event):
    sliderRep = obj.GetRepresentation()
    position = sliderRep.GetValue()
    print "Position ",position
    iso.SetValue(0, position)
    
#***************************************************************************************
# 100^3 sampling data set of the quadratic function x2 + 0:65y2 + 0:25z2 + 0:1xz + 0:2x.

#Having a data source for an implicit function in the form of;
#f(x,y,z)=a0*x^2+a1*y^2+a2*z^2 + a3*x*y + a4*y*z + a5*x*z + a6*x + a7*y + a8*z + a9
#F(x,y,z) = a0x2+ a1y2+ a2z2+ a3xy + a4yz + a5xz + a6x + a7y + a8z + a9
quadric = vtk.vtkQuadric() 
#Replacing with our function x2 + 0:65y2 + 0:25z2 + 0:1xz + 0:2x we have;
#f(x,y,z)= 1x^2+0.65y^2+0.25z^2+0xy+0yz+0.1xz+0.2x+0y+0z+0
quadric.SetCoefficients(1, 0.65, 0.25, 0, 0, 0.1, 0.2, 0, 0, 0) 

#*****************************************************************************************
#sampling function
sample = vtk.vtkSampleFunction() 
sample.SetSampleDimensions(100, 100, 100) 
sample.SetImplicitFunction(quadric)
max = 1.5 #Maximum slider value 
min = 0.05 #minimum slider value
print("Use your mouse to interact with the Quadric")

#countour of input data computation function
iso = vtk.vtkContourFilter() 
iso.SetInputConnection(sample.GetOutputPort())
iso.SetValue(0,(min + max) / 2) 

isoMapper = vtk.vtkPolyDataMapper() 
isoMapper.SetInput( iso.GetOutput() ) 
isoActor = vtk.vtkActor() 
isoActor.SetMapper(isoMapper)
isoMapper.SetColorModeToMapScalars() 


#Creating outline  
outline = vtk.vtkOutlineFilter() 
outline.SetInput( sample.GetOutput() ) 
outlineMapper = vtk.vtkPolyDataMapper() 
outlineMapper.SetInput( outline.GetOutput() )
outlineActor = vtk.vtkActor() 
outlineActor.SetMapper( outlineMapper ) 
outlineActor.GetProperty().SetColor(1,1,1)   

# creating the renderer & render window 
rend = vtk.vtkRenderer() 
rend.SetBackground(0, 0, 0)
rendWin = vtk.vtkRenderWindow() 
rendWin.SetSize( 600, 600 ) 
rendWin.AddRenderer( rend ) 
 
# render window interactor 
int_rend = vtk.vtkRenderWindowInteractor() 
int_rend.SetSize(1600,1600)
int_rend.SetRenderWindow( rendWin )

# add the actors 
rend.AddActor( outlineActor ) 
rend.AddActor( isoActor )    
  

 #Interactive_Representation 

SliderRep = vtk.vtkSliderRepresentation2D()
SliderRep.SetMinimumValue(min)
SliderRep.SetMaximumValue(max)
SliderRep.SetValue((min + max) / 2)
SliderRep.SetTitleText("Isosurface_Interactive_Slider")
SliderRep.GetPoint1Coordinate().SetCoordinateSystemToNormalizedDisplay()
SliderRep.GetPoint1Coordinate().SetValue(0.3, 0.05)
SliderRep.GetPoint2Coordinate().SetCoordinateSystemToNormalizedDisplay()
SliderRep.GetPoint2Coordinate().SetValue(0.7, 0.05)


SliderRep.SetSliderLength(0.02)
SliderRep.SetSliderWidth(0.03)
SliderRep.SetTubeWidth(0.005)
SliderRep.SetTitleHeight(0.02)
SliderRep.SetEndCapLength(0.01)
SliderRep.SetEndCapWidth(0.03)
SliderRep.SetLabelHeight(0.02)
SliderRep.GetSelectedProperty().SetColor(0,1,0)


SliderWidget = vtk.vtkSliderWidget()
SliderWidget.SetInteractor(int_rend)
SliderWidget.KeyPressActivationOff()
SliderWidget.SetAnimationModeToAnimate()
SliderWidget.SetRepresentation(SliderRep)
SliderWidget.SetEnabled(True)
SliderWidget.AddObserver("EndInteractionEvent", vtkSliderCallback2)

# Executing pipeline
rendWin.Render() 

# initializing & starting interactor
int_rend.Initialize() 
int_rend.Start() 

