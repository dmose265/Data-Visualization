Project 2 Data visualization Assigment.
Force directed graphs were developed using webstorm & xampp application.
Files:
nfl data matrix generated from the NFL website in CSV format.

graph 1  is a force directed draggable graph that shows team groups, team names, team location on US map.

graph 2 is draggable too. shows team record in the nfl  standings during the 2020 regular season.

Graph 3 is similar to graph 1 but is not undraggable .

images folder contains images generated from the graphs.


dmose@iu.edu.
Dennis Masigwa.

